InlineQueryResultArticle
========================

.. autoclass:: telegram.InlineQueryResultArticle
    :members:
    :show-inheritance:
