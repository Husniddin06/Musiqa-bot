WebAppData
==========

.. autoclass:: telegram.WebAppData
    :members:
    :show-inheritance: