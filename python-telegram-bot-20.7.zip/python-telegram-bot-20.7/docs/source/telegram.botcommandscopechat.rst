BotCommandScopeChat
===================

.. autoclass:: telegram.BotCommandScopeChat
    :members:
    :show-inheritance: