Updater
=======

.. autoclass:: telegram.ext.Updater
    :members:
    :show-inheritance:
    :special-members: __repr__
