InlineQueryResultCachedSticker
==============================

.. autoclass:: telegram.InlineQueryResultCachedSticker
    :members:
    :show-inheritance:
