CallbackContext
===============

.. autoclass:: telegram.ext.CallbackContext
    :members:
