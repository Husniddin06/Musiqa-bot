WriteAccessAllowed
==================

.. autoclass:: telegram.WriteAccessAllowed
    :members:
    :show-inheritance:
