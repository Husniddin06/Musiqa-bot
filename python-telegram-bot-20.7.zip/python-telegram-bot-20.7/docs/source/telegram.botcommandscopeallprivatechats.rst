BotCommandScopeAllPrivateChats
==============================

.. autoclass:: telegram.BotCommandScopeAllPrivateChats
    :members:
    :show-inheritance: