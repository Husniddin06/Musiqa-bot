Payments
--------

.. toctree::
    :titlesonly:

    telegram.invoice
    telegram.labeledprice
    telegram.orderinfo
    telegram.precheckoutquery
    telegram.shippingaddress
    telegram.shippingoption
    telegram.shippingquery
    telegram.successfulpayment
