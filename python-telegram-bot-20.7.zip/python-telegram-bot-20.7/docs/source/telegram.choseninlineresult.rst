ChosenInlineResult
==================

.. autoclass:: telegram.ChosenInlineResult
    :members:
    :show-inheritance:
