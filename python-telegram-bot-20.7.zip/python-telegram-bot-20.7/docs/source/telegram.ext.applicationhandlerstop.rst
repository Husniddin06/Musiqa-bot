ApplicationHandlerStop
======================

.. autoclass:: telegram.ext.ApplicationHandlerStop
    :members:
    :show-inheritance:
