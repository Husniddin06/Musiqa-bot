BotCommandScopeChatMember
=========================

.. autoclass:: telegram.BotCommandScopeChatMember
    :members:
    :show-inheritance: