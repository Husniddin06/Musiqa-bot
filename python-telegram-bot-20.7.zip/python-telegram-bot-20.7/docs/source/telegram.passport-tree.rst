Passport
--------

.. toctree::
    :titlesonly:

    telegram.credentials
    telegram.datacredentials
    telegram.encryptedcredentials
    telegram.encryptedpassportelement
    telegram.filecredentials
    telegram.iddocumentdata
    telegram.passportdata
    telegram.passportelementerror
    telegram.passportelementerrordatafield
    telegram.passportelementerrorfile
    telegram.passportelementerrorfiles
    telegram.passportelementerrorfrontside
    telegram.passportelementerrorreverseside
    telegram.passportelementerrorselfie
    telegram.passportelementerrortranslationfile
    telegram.passportelementerrortranslationfiles
    telegram.passportelementerrorunspecified
    telegram.passportfile
    telegram.personaldetails
    telegram.residentialaddress
    telegram.securedata
    telegram.securevalue
