SwitchInlineQueryChosenChat
===========================

.. autoclass:: telegram.SwitchInlineQueryChosenChat
    :members:
    :show-inheritance:
