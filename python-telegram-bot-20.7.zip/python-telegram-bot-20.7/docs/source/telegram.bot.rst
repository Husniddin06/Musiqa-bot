Bot
===

.. autoclass:: telegram.Bot
    :members:
    :show-inheritance:
    :special-members: __repr__, __reduce__, __deepcopy__