InputMediaDocument
==================

.. autoclass:: telegram.InputMediaDocument
    :members:
    :show-inheritance:
