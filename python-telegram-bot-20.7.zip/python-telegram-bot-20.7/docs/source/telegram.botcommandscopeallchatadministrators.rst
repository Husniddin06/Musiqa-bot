BotCommandScopeAllChatAdministrators
====================================

.. autoclass:: telegram.BotCommandScopeAllChatAdministrators
    :members:
    :show-inheritance: