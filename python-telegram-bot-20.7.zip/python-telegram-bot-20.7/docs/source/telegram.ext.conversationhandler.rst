ConversationHandler
===================

.. autoclass:: telegram.ext.ConversationHandler
    :members:
    :show-inheritance:
    :special-members: __repr__
