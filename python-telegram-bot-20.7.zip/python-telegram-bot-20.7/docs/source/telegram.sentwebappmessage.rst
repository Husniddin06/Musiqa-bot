SentWebAppMessage
=================

.. autoclass:: telegram.SentWebAppMessage
    :members:
    :show-inheritance: