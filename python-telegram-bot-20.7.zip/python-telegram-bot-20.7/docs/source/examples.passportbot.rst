``passportbot.py``
==================

.. literalinclude:: ../../examples/passportbot.py
   :language: python
   :linenos:

.. _passportbot-html:

HTML Page
---------

.. literalinclude:: ../../examples/passportbot.html
   :language: html
   :linenos:
    