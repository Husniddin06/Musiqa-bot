InputMediaAudio
===============

.. autoclass:: telegram.InputMediaAudio
    :members:
    :show-inheritance:
