ChatPhoto
=========

.. autoclass:: telegram.ChatPhoto
    :members:
    :show-inheritance:
