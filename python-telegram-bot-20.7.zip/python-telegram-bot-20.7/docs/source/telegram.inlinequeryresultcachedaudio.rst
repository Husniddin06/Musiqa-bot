InlineQueryResultCachedAudio
============================

.. autoclass:: telegram.InlineQueryResultCachedAudio
    :members:
    :show-inheritance:
