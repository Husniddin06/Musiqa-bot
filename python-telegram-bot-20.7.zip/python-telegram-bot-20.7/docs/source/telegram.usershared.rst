UserShared
===================

.. autoclass:: telegram.UserShared
    :members:
    :show-inheritance:
