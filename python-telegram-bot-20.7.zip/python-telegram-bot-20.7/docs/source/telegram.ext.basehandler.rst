BaseHandler
===========

.. autoclass:: telegram.ext.BaseHandler
    :members:
    :show-inheritance:
    :special-members: __repr__
