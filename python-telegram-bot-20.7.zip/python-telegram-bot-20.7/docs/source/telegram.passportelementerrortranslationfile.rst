PassportElementErrorTranslationFile
===================================

.. autoclass:: telegram.PassportElementErrorTranslationFile
    :members:
    :show-inheritance:
