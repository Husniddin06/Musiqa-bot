ForumTopicEdited
================

.. autoclass:: telegram.ForumTopicEdited
    :members:
    :show-inheritance:
