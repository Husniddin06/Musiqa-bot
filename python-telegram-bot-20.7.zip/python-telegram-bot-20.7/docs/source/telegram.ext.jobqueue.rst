JobQueue
========

.. autoclass:: telegram.ext.JobQueue
    :members:
    :show-inheritance:
    :special-members: __repr__
