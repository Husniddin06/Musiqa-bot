Application
===========

.. autoclass:: telegram.ext.Application
    :members:
    :show-inheritance:
    :special-members: __repr__
