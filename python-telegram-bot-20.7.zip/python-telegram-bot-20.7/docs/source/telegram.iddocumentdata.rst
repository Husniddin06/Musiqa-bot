IdDocumentData
==============

.. autoclass:: telegram.IdDocumentData
    :members:
    :show-inheritance:
